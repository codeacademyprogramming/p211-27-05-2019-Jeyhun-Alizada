const textarea = document.querySelector("textarea");
const main = document.getElementsByClassName("main")[0];
const add = document.getElementsByClassName("btn")[0];
// add.onclick = function() {
//   main.innerHTML = "Mən:  " + textarea.value;
//   textarea.value ="";
// };
document.onkeydown = function(e) {
  if (e.keyCode === 13) {
    e.preventDefault();
    const messageBox = document.createElement("p");
    messageBox.innerHTML = "Mən:  " + textarea.value;
    textarea.value = "";
    main.classList.add("main");
    main.appendChild(messageBox);
  }
};

